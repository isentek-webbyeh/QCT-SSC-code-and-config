/*==============================================================================    

EDIT HISTORY FOR FILE

This section contains comments describing changes made to the module.
Notice that changes are listed in reverse chronological order.

when         who     what, where, why
----------   ---     -----------------------------------------------------------
2015/12/24  tyhuang     1. v1.0.0
                        2. crossaxis modified
                        3. "MSensorLog" for debug specified
==============================================================================*/

/*============================================================================
INCLUDE FILES
============================================================================*/
#include "sns_ddf_attrib.h"
#include "sns_ddf_common.h"
#include "sns_ddf_comm.h"
#include "sns_ddf_driver_if.h"
#include "sns_ddf_smgr_if.h"
#include "sns_ddf_util.h"
#include "sns_ddf_memhandler.h"
#include "sns_ddf_signal.h"
#include "dd_vendor_1.h"

#include <math.h>
//#define NULL ((void *)0)

#define DD_MSG_0(level,msg) MSG(MSG_SSID_QDSP6,DBG_##level##_PRIO, "DD - " msg)

typedef struct 
{
    sns_ddf_handle_t smgr_hndl;
    sns_ddf_handle_t port_handle;
    uint8_t range;
    uint16_t lowpass_bw;
    q16_t  bias[3];
    q16_t data_cache[3];	
    uint32_t odr_value;
    uint64_t previous_timestamp;
	sns_ddf_axes_map_s       axes_map;
    sns_dd_nv_db_type sns_dd_common_db;
} sns_dd_mag_state_t;

typedef struct _ODR_ITEM
{
    uint32_t hz;
    uint32_t delayms;
    uint32_t regval;
} ODR_ITEM;

static ODR_ITEM ODR_TABLE[] = 
{
    {  8,  125,  2},
    { 10,  100,  3},
    { 20,   50,  5},
    {100,   10,  6},
    { 50,   20,  7},
    {  1, 1000, 10},
    {200,    5, 11},
};
int init_lock = 0;
sns_ddf_odr_t mag_odr_list[7] = {1, 8, 10, 20, 50, 100, 200};
#ifdef IST_CROSS_AXIS_CALI
#ifdef SUPPORT_FLOAT_TYPE
float crossaxis_inv[3][3];
#define OTPsensitivity (330)
#else
int64_t crossaxis_inv[9];
int32_t crossaxis_det[1];
//crossaxis cali_sensitivity and bit shift setting
#define OTPsensitivity (330)
#define crossaxisinv_bitshift (16)
#endif
#endif

#ifdef SUPPORT_FLOAT_TYPE
char I_InvertMatrix3by3(float *invIn, float *invOut)
{
    float largest;					// largest element used for pivoting
	float scaling;					// scaling factor in pivoting
	float recippiv;					// reciprocal of pivot element
	float ftmp;						// temporary variable used in swaps
	int i, j, k, l, m;				// index counters
	int iPivotRow, iPivotCol;		// row and column of pivot element
	int iPivot[3]={0};
	int isize=3;
	int iRowInd[3] = {0};
	int	iColInd[3] = {0};
	float A[3][3];
	for(i=0;i<3;i++)
		for(j=0;j<3;j++)
		{
			A[i][j]= invIn[i+j*3];
		}
	//printf("%f %f %f %f",A[0][0],A[1][1],A[2][2],A[3][3]);
	// to avoid compiler warnings
	iPivotRow = iPivotCol = 0;

	// main loop i over the dimensions of the square matrix A
	for (i = 0; i < isize; i++)
	{
		// zero the largest element found for pivoting
		largest = 0.0F;
		// loop over candidate rows j
		for (j = 0; j < isize; j++)
		{
			// check if row j has been previously pivoted
			if (iPivot[j] != 1)
			{
				// loop over candidate columns k
				for (k = 0; k < isize; k++)
				{
					// check if column k has previously been pivoted
					if (iPivot[k] == 0)
					{
						// check if the pivot element is the largest found so far
						if (fabs(A[j][k]) >= largest)
						{
							// and store this location as the current best candidate for pivoting
							iPivotRow = j;
							iPivotCol = k;
							largest = (float) fabs(A[iPivotRow][iPivotCol]);
						}
					}
					else if (iPivot[k] > 1)
					{
						// zero determinant situation: exit with identity matrix
						//fmatrixAeqI(A, isize);
					 return -1;
					}
				}
			}
		}
		// increment the entry in iPivot to denote it has been selected for pivoting
		iPivot[iPivotCol]++;

		// check the pivot rows iPivotRow and iPivotCol are not the same before swapping
		if (iPivotRow != iPivotCol)
		{
			// loop over columns l
			for (l = 0; l < isize; l++)
			{
				// and swap all elements of rows iPivotRow and iPivotCol
				ftmp = A[iPivotRow][l];
				A[iPivotRow][l] = A[iPivotCol][l];
				A[iPivotCol][l] = ftmp;
			}
		}

		// record that on the i-th iteration rows iPivotRow and iPivotCol were swapped
		iRowInd[i] = iPivotRow;
		iColInd[i] = iPivotCol;

		// check for zero on-diagonal element (singular matrix) and return with identity matrix if detected
		if (A[iPivotCol][iPivotCol] == 0.0F)
		{
			// zero determinant situation: exit with identity matrix
			//fmatrixAeqI(A, isize);
			 return -1;
		}

		// calculate the reciprocal of the pivot element knowing it's non-zero
		recippiv = 1.0F / A[iPivotCol][iPivotCol];
		// by definition, the diagonal element normalizes to 1
		A[iPivotCol][iPivotCol] = 1.0F;
		// multiply all of row iPivotCol by the reciprocal of the pivot element including the diagonal element
		// the diagonal element A[iPivotCol][iPivotCol] now has value equal to the reciprocal of its previous value
		for (l = 0; l < isize; l++)
		{
			A[iPivotCol][l] *= recippiv;
		}
		// loop over all rows m of A
		for (m = 0; m < isize; m++)
		{
			if (m != iPivotCol)
			{
				// scaling factor for this row m is in column iPivotCol
				scaling = A[m][iPivotCol];
				// zero this element
				A[m][iPivotCol] = 0.0F;
				// loop over all columns l of A and perform elimination
				for (l = 0; l < isize; l++)
				{
					A[m][l] -= A[iPivotCol][l] * scaling;
				}
			}
		}
	} // end of loop i over the matrix dimensions

	// finally, loop in inverse order to apply the missing column swaps
	for (l = isize - 1; l >= 0; l--)
	{
		// set i and j to the two columns to be swapped
		i = iRowInd[l];
		j = iColInd[l];

		// check that the two columns i and j to be swapped are not the same
		if (i != j)
		{
			// loop over all rows k to swap columns i and j of A
			for (k = 0; k < isize; k++)
			{
				ftmp = A[k][i];
				A[k][i] = A[k][j];
				A[k][j] = ftmp;
			}
		}
	}
//		printf("%f %f %f %f",A[0][0],A[1][1],A[2][2],A[3][3]);
		for(i=0;i<3;i++)
		for(j=0;j<3;j++)
		{
			 invOut[i+j*3]=A[i][j];
		}
   return 0;

}
#endif

#ifdef IST_CROSS_AXIS_CALI
#if 0
static sns_ddf_status_e i2c_write(sns_ddf_handle_t dd_handle, uint8_t reg, uint8_t data)
{
    sns_dd_mag_state_t*     ptr;
    sns_ddf_status_e status;    
    uint8_t out;
    ptr = (sns_dd_mag_state_t*)dd_handle;
    status = sns_ddf_write_port(ptr->port_handle, reg, &data, 1, &out);
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [i2c_write] error");
    }
    return status;
}
#endif
static sns_ddf_status_e i2c_read(sns_ddf_handle_t dd_handle, uint8_t reg, uint8_t length, uint8_t* data)
{
    sns_ddf_status_e status;    
    uint8_t out;
    //uint8_t temp_data[32];
    //int i;
    
    status = sns_ddf_read_port(dd_handle, reg, data, length, &out);
    if(status != SNS_DDF_SUCCESS)
        DD_MSG_0(HIGH, "MSensorLog [i2c_read] error");
    //for(i=0;i<length;i++)
        //*(data+i) = temp_data[i];

    return status;
    
}

void IST8307_CrossaxisTransformation(int16_t *xyz){
    int i = 0;
#ifdef SUPPORT_FLOAT_TYPE
    int16_t outputtmp[3];
    outputtmp[0] = (*xyz) * crossaxis_inv[0][0] +
                   (*(xyz+1)) * crossaxis_inv[1][0] +
                   (*(xyz+2)) * crossaxis_inv[2][0];

    outputtmp[1] = (*xyz) * crossaxis_inv[0][1] +
                   (*(xyz+1)) * crossaxis_inv[1][1] +
                   (*(xyz+2)) * crossaxis_inv[2][1];
    
    outputtmp[2] = (*xyz) * crossaxis_inv[0][2] +
                   (*(xyz+1)) * crossaxis_inv[1][2] +
                   (*(xyz+2)) * crossaxis_inv[2][2];

    for (i=0; i<IST8307_AXES_NUM; i++)
        *(xyz+i) = (short)outputtmp[i];
#else	
	int64_t outputtmp[3];
    for( i = 0; i < 9; i++){
        if(crossaxis_inv[i]!=0)
          break;
        //if(i == 8)
          //IST8307_Init();
    }
    outputtmp[0] = xyz[0] * crossaxis_inv[0] +
                   xyz[1] * crossaxis_inv[1] +
                   xyz[2] * crossaxis_inv[2];

    outputtmp[1] = xyz[0] * crossaxis_inv[3] +
                   xyz[1] * crossaxis_inv[4] +
                   xyz[2] * crossaxis_inv[5];
    
    outputtmp[2] = xyz[0] * crossaxis_inv[6] +
                   xyz[1] * crossaxis_inv[7] +
                   xyz[2] * crossaxis_inv[8];

    for (i=0; i<IST8307_AXES_NUM; i++)
    {
        outputtmp[i] = outputtmp[i] / (*crossaxis_det);
    }
    xyz[0]= (short)(outputtmp[0] >> crossaxisinv_bitshift);
    xyz[1]= (short)(outputtmp[1] >> crossaxisinv_bitshift);
    xyz[2]= (short)(outputtmp[2] >> crossaxisinv_bitshift);
#endif
}
#endif
#if 0
void IST8307_GetXYZ(int16_t *xyz){
    uint8_t raw[IST8307_DATA_NUM];
    //Write ODR to force mode
    i2c_write(dd_handle, IST8307_REG_CNTRL1, IST8307_ODR_MODE);
    //Read 6 reg data from x high&low to z
    i2c_read(dd_handle, IST8307_REG_DATAX, IST8307_DATA_NUM, raw);
    //Combine High Low byte
    IST8307_MergeHighLowData(raw, xyz);
#ifdef IST_CROSS_AXIS_CALI
    IST8307_CrossaxisTransformation(xyz);
#endif
}
#endif
#ifdef IST_CROSS_AXIS_CALI
#ifdef SUPPORT_FLOAT_TYPE
void IST8307_Crossaxis_Matrix(sns_ddf_handle_t dd_handle,int enable)
{
    int i = 0, j;
    unsigned char crossxbuf[6];
    unsigned char crossybuf[6];
    unsigned char crosszbuf[6];
    float OTPcrossaxis[3][3];   
    
    if (enable == 0)
    {
//DET_eql_0:
    memset(crossaxis_inv, 0 ,9);
    crossaxis_inv[0][0] = crossaxis_inv[1][1] = crossaxis_inv[2][2] = 1;
        return;
    }    
    else
    {
        i2c_read(dd_handle,IST8307_REG_XX_CROSS_L,6,crossxbuf);
        i2c_read(dd_handle,IST8307_REG_YX_CROSS_L,6,crossybuf);
        i2c_read(dd_handle,IST8307_REG_ZX_CROSS_L,6,crosszbuf);

        OTPcrossaxis[0][0] = (float)(short)(((crossxbuf[1] << 8) | (crossxbuf[0]))); //328
        OTPcrossaxis[0][1] = (float)(short)(((crossxbuf[3] << 8) | (crossxbuf[2]))); //9
        OTPcrossaxis[0][2] = (float)(short)(((crossxbuf[5] << 8) | (crossxbuf[4]))); //19
        OTPcrossaxis[1][0] = (float)(short)(((crossybuf[1] << 8) | (crossybuf[0]))); //-7
        OTPcrossaxis[1][1] = (float)(short)(((crossybuf[3] << 8) | (crossybuf[2]))); //326
        OTPcrossaxis[1][2] = (float)(short)(((crossybuf[5] << 8) | (crossybuf[4]))); //2
        OTPcrossaxis[2][0] = (float)(short)(((crosszbuf[1] << 8) | (crosszbuf[0])));    //36
        OTPcrossaxis[2][1] = (float)(short)(((crosszbuf[3] << 8) | (crosszbuf[2])));    //27
        OTPcrossaxis[2][2] = (float)(short)(((crosszbuf[5] << 8) | (crosszbuf[4])));   //335
#if 1
for(i=0;i<9;i++)
   			IST8307_MSG_2(HIGH, "MSensorLog>OPT matrix[%d]--= %d<<<<<<<", i, OTPcrossaxis[i]);
#endif
        I_InvertMatrix3by3(&OTPcrossaxis[0][0], &crossaxis_inv[0][0]);
        for(i=0;i<3;i++)
            for(j=0;j<3;j++)
                crossaxis_inv[i][j] = crossaxis_inv[i][j]*OTPsensitivity;
    }
    return;
}
#else
void IST8307_Crossaxis_Matrix(sns_ddf_handle_t dd_handle, int bitshift, int enable)
{
//    int ret;
    int i = 0;
    uint8_t crossxbuf[6];
    uint8_t crossybuf[6];
    uint8_t crosszbuf[6];
    short OTPcrossaxis[9] = {0}; 
    int64_t inv[9] = {0};
    
    if (enable == 0)
    {
DET_eql_0:
        *crossaxis_inv = (1<<bitshift);
        *(crossaxis_inv+1) = 0;
        *(crossaxis_inv+2) = 0;
        *(crossaxis_inv+3) = 0;
        *(crossaxis_inv+4) = (1<<bitshift);
        *(crossaxis_inv+5) = 0;
        *(crossaxis_inv+6) = 0;
        *(crossaxis_inv+7) = 0;
        *(crossaxis_inv+8) = (1<<bitshift); 
        *crossaxis_det = 1;

//        for (i=0; i<9; i++)
//        {
//            printf("*(crossaxis_inv + %d) = %lld\n", i, *(crossaxis_inv+i));
//        }
//        printf("det = %d\n",*crossaxis_det);
        return;
    }    
    else
    {
        i2c_read(dd_handle, IST8307_REG_XX_CROSS_L, 6, crossxbuf);
        i2c_read(dd_handle, IST8307_REG_YX_CROSS_L, 6, crossybuf);
        i2c_read(dd_handle, IST8307_REG_ZX_CROSS_L, 6, crosszbuf);

        OTPcrossaxis[0] = ((int) crossxbuf[1]) << 8 | ((int) crossxbuf[0]);
        OTPcrossaxis[3] = ((int) crossxbuf[3]) << 8 | ((int) crossxbuf[2]);
        OTPcrossaxis[6] = ((int) crossxbuf[5]) << 8 | ((int) crossxbuf[4]);
        OTPcrossaxis[1] = ((int) crossybuf[1]) << 8 | ((int) crossybuf[0]);
        OTPcrossaxis[4] = ((int) crossybuf[3]) << 8 | ((int) crossybuf[2]);
        OTPcrossaxis[7] = ((int) crossybuf[5]) << 8 | ((int) crossybuf[4]);
        OTPcrossaxis[2] = ((int) crosszbuf[1]) << 8 | ((int) crosszbuf[0]);
        OTPcrossaxis[5] = ((int) crosszbuf[3]) << 8 | ((int) crosszbuf[2]);
        OTPcrossaxis[8] = ((int) crosszbuf[5]) << 8 | ((int) crosszbuf[4]);

#if 1
for(i=0;i<9;i++)
   			IST8307_MSG_2(HIGH, "MSensorLog>OPT matrix[%d]--= %d<<<<<<<", i, OTPcrossaxis[i]);
#endif

        *crossaxis_det = ((int32_t)OTPcrossaxis[0])*OTPcrossaxis[4]*OTPcrossaxis[8] +
               ((int32_t)OTPcrossaxis[1])*OTPcrossaxis[5]*OTPcrossaxis[6] +
               ((int32_t)OTPcrossaxis[2])*OTPcrossaxis[3]*OTPcrossaxis[7] -
               ((int32_t)OTPcrossaxis[0])*OTPcrossaxis[5]*OTPcrossaxis[7] -
               ((int32_t)OTPcrossaxis[2])*OTPcrossaxis[4]*OTPcrossaxis[6] -
               ((int32_t)OTPcrossaxis[1])*OTPcrossaxis[3]*OTPcrossaxis[8];
        
        if (*crossaxis_det == 0) {
            goto DET_eql_0;
        }
        
        inv[0] = (int64_t)OTPcrossaxis[4] * OTPcrossaxis[8] - (int64_t)OTPcrossaxis[5] * OTPcrossaxis[7];
        inv[1] = (int64_t)OTPcrossaxis[2] * OTPcrossaxis[7] - (int64_t)OTPcrossaxis[1] * OTPcrossaxis[8];
        inv[2] = (int64_t)OTPcrossaxis[1] * OTPcrossaxis[5] - (int64_t)OTPcrossaxis[2] * OTPcrossaxis[4];
        inv[3] = (int64_t)OTPcrossaxis[5] * OTPcrossaxis[6] - (int64_t)OTPcrossaxis[3] * OTPcrossaxis[8];
        inv[4] = (int64_t)OTPcrossaxis[0] * OTPcrossaxis[8] - (int64_t)OTPcrossaxis[2] * OTPcrossaxis[6];
        inv[5] = (int64_t)OTPcrossaxis[2] * OTPcrossaxis[3] - (int64_t)OTPcrossaxis[0] * OTPcrossaxis[5];
        inv[6] = (int64_t)OTPcrossaxis[3] * OTPcrossaxis[7] - (int64_t)OTPcrossaxis[4] * OTPcrossaxis[6];
        inv[7] = (int64_t)OTPcrossaxis[1] * OTPcrossaxis[6] - (int64_t)OTPcrossaxis[0] * OTPcrossaxis[7];
        inv[8] = (int64_t)OTPcrossaxis[0] * OTPcrossaxis[4] - (int64_t)OTPcrossaxis[1] * OTPcrossaxis[3];
        
        for (i=0; i<9; i++) {
            crossaxis_inv[i] = (inv[i] << bitshift) * OTPsensitivity;
        }
    }
    
    return;
}
#endif
#endif
static uint32_t sns_dd_mag_get_ODR(uint32_t odr);

static sns_ddf_status_e sns_dd_mag_init(sns_dd_mag_state_t* ptr);

static sns_ddf_status_e sns_dd_mag_config_power_mode(sns_dd_mag_state_t* dd_handle, sns_ddf_powerstate_e mode);

static sns_ddf_status_e sns_dd_mag_config_ODR(sns_dd_mag_state_t* dd_handle, uint32_t* odr);

static sns_ddf_status_e sns_dd_init
(
    sns_ddf_handle_t*        dd_handle_ptr,
    sns_ddf_handle_t         smgr_handle,
    sns_ddf_nv_params_s*     nv_params,
    sns_ddf_device_access_s  device_info[],
    uint32_t                 num_devices,
    sns_ddf_memhandler_s*    memhandler,
    sns_ddf_sensor_e*        sensors[],
    uint32_t*                num_sensors
);

static sns_ddf_status_e sns_dd_get_data
(
    sns_ddf_handle_t        dd_handle,
    sns_ddf_sensor_e        sensors[],
    uint32_t                num_sensors,
    sns_ddf_memhandler_s*   memhandler,
    sns_ddf_sensor_data_s*  data[]
);

static sns_ddf_status_e sns_dd_set_attrib
(
    sns_ddf_handle_t     dd_handle,
    sns_ddf_sensor_e     sensor,
    sns_ddf_attribute_e  attrib,
    void*                value
);

static sns_ddf_status_e sns_dd_get_attrib
(
    sns_ddf_handle_t     dd_handle,
    sns_ddf_sensor_e     sensor,
    sns_ddf_attribute_e  attrib,
    sns_ddf_memhandler_s* memhandler,
    void**               value,
    uint32_t*            num_elems
);

static void sns_dd_handle_timer 
(
    sns_ddf_handle_t dd_handle, 
    void* arg
);

static void sns_dd_handle_irq
(
    sns_ddf_handle_t dd_handle, 
    uint32_t          gpio_num,
    sns_ddf_time_t    timestamp
);

static sns_ddf_status_e sns_dd_reset
(
    sns_ddf_handle_t dd_handle
);

static sns_ddf_status_e sns_dd_enable_sched_data
(
    sns_ddf_handle_t  handle,
    sns_ddf_sensor_e  sensor,
    bool              enable
);

static sns_ddf_status_e sns_dd_run_test
(
    sns_ddf_handle_t  dd_handle,
    sns_ddf_sensor_e  sensor,
    sns_ddf_test_e    test,
    uint32_t*         err
);

static sns_ddf_status_e sns_dd_probe
(
    sns_ddf_device_access_s* device_info,
    sns_ddf_memhandler_s*    memhandler,
    uint32_t*                num_sensors,
    sns_ddf_sensor_e**       sensors
);

sns_ddf_driver_if_s sns_dd_vendor_if_1 =
{
    .init = &sns_dd_init,
    .get_data = &sns_dd_get_data,
    .set_attrib = &sns_dd_set_attrib, 
    .get_attrib = &sns_dd_get_attrib,
    .handle_timer = &sns_dd_handle_timer,
    .handle_irq = &sns_dd_handle_irq,
    .reset = &sns_dd_reset,
    .run_test = &sns_dd_run_test,
    .enable_sched_data = &sns_dd_enable_sched_data,
    .probe = &sns_dd_probe
};

//sns_ddf_handle_t mag_port_handle;

/*===========================================================================

FUNCTION:   sns_dd_handle_irq

===========================================================================*/
/*!
@brief Interrupt handler

@detail
Called in response to an interrupt for this driver.

@see sns_ddf_driver_if_s.handle_irq()

@param[in] dd_handle  Handle to a driver instance. 
@param[in] irq        The IRQ representing the interrupt that occured. 

@return None 
*/
/*=========================================================================*/
static void sns_dd_handle_irq(
    sns_ddf_handle_t  handle,
    uint32_t          gpio_num,
    sns_ddf_time_t    timestamp
)
{
    DD_MSG_0(HIGH, "MSensorLog [sns_dd_handle_irq] not support");
}

/*===========================================================================

FUNCTION:   sns_dd_handle_timer

===========================================================================*/
/*!
@brief Called when the timer set by this driver has expired. This is  
the callback function submitted when initializing a timer.

@detail
This will be called within the context of the Sensors Manager task.
It indicates that sensor data is ready

@param[in] dd_handle  Handle to a driver instance. 
@param[in] arg        The argument submitted when the timer was set. 

@return None 
*/
/*=========================================================================*/
static void sns_dd_handle_timer(
    sns_ddf_handle_t handle, 
    void* arg
)
{
    DD_MSG_0(HIGH, "MSensorLog [sns_dd_handle_timer]");
}

/*===========================================================================

FUNCTION:   sns_dd_reset

===========================================================================*/
/*!
@brief Resets the driver and device so they return to the state they were 
in after init() was called.

@detail
Resets  the driver state structure

@param[in] handle  Handle to a driver instance.

@return Success if the driver was able to reset its state and the device.
Otherwise a specific error code is returned. 
*/
/*=========================================================================*/
static sns_ddf_status_e sns_dd_reset(
    sns_ddf_handle_t dd_handle
)
{
    sns_dd_mag_state_t *ptr;
    sns_ddf_status_e status;
    uint8_t data, out;
    int i;
    
    ptr = (sns_dd_mag_state_t*)dd_handle;
/*    
    data = 0x1; //Soft reset
    status = sns_ddf_write_port(ptr->port_handle, IST8307_REG_CNTRL2, &data, 1, &out);
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_reset] reset error");
    }
*/	
    data = 0; //Standby mode
    status = sns_ddf_write_port(ptr->port_handle, IST8307_REG_CNTRL1, &data, 1, &out);
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_reset] standby error");
    }
    DD_MSG_0(HIGH, "MSensorLog [sns_dd_reset] done");
    return SNS_DDF_SUCCESS;
}

/*===========================================================================

FUNCTION:   sns_dd_init

===========================================================================*/
/*!
@brief Initializes the Ambient Light Sensing and Proximity device driver
Allocates a handle to a driver instance, opens a communication port to 
associated devices, configures the driver and devices, and places 
the devices in the default power state. Returns the instance handle along 
with a list of supported sensors. This function will be called at init 
time.

@param[out] dd_handle_ptr  Pointer that this function must malloc and 
populate. This is a handle to the driver
instance that will be passed in to all other
functions. NB: Do not use @a memhandler to
allocate this memory.
@param[in]  smgr_handle    Handle used to identify this driver when it 
calls into Sensors Manager functions.
@param[in]  nv_params      NV parameters retrieved for the driver.
@param[in]  device_info    Access info for physical devices controlled by 
this driver. Used to configure the bus
and talk to the devices.
@param[in]  num_devices    Number of elements in @a device_info. 
@param[in]  memhandler     Memory handler used to dynamically allocate 
output parameters, if applicable. NB: Do not
use memhandler to allocate memory for
@a dd_handle_ptr.
@param[out] sensors        List of supported sensors, allocated, 
populated, and returned by this function.
@param[out] num_sensors    Number of elements in @a sensors.

@return Success if @a dd_handle_ptr was allocated and the driver was 
configured properly. Otherwise a specific error code is returned.

*/
/*=========================================================================*/                                             
static sns_ddf_status_e sns_dd_mag_init(sns_dd_mag_state_t* ptr)
{
    sns_ddf_status_e status;
    uint8_t data, out;
    DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_init]");

	if(init_lock==1)
	{
		DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_init] init locked");
		return SNS_DDF_SUCCESS;
	}

    data = 0x1; //Soft reset
    status = sns_ddf_write_port(ptr->port_handle, IST8307_REG_CNTRL2, &data, 1, &out);
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_init] reset error");
    }

    sns_ddf_delay(10000);
	
    data = 0x00;  //  stand-by mode    
    status = sns_ddf_write_port(ptr->port_handle, IST8307_REG_CNTRL1, &data, 1, &out);
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_init] error#1");
        return status;
    }

    //data = 0;
    status = sns_ddf_write_port(ptr->port_handle, IST8307_REG_CNTRL2, &data, 1, &out);
    if(status != SNS_DDF_SUCCESS)
    {
       DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_init] error#2");
       return status;
    }

    data = IST8307_REG_CNTRL2 & 0xF3;  //  clear bit2 & bit3 to disable DRDY external pin
    status = sns_ddf_write_port(ptr->port_handle, IST8307_REG_CNTRL2, &data, 1, &out);
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_init] error#3");
        return status;
    }

    data = 0xC0;  //  set to 1us pulse duration + low power mode  
    status = sns_ddf_write_port(ptr->port_handle, IST8307_REG_SSR, &data, 1, &out);
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_init] error#4");
        return status;
     }

#ifdef SUPPORT_8307 //set 16 times average
    data = 0x24;  //  set to 1us pulse duration + low power mode  
    status = sns_ddf_write_port(ptr->port_handle, IST8307_REG_HW_AVE, &data, 1, &out);
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_init] hw_ave error!");
        return status;
     }
#endif

    data = 0x00;
    status = sns_ddf_write_port(ptr->port_handle, IST8307_REG_CTR, &data, 1, &out);
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_init] error#5");
        return status;
    }

    data = 0x00;  //  only for pulse width
    status = sns_ddf_write_port(ptr->port_handle, 0x62, &data, 1, &out);
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_init] error#6");
        return status;
    }
	init_lock=1;
    return SNS_DDF_SUCCESS;
}

static sns_ddf_status_e sns_dd_init(
    sns_ddf_handle_t*        dd_handle_ptr,
    sns_ddf_handle_t         smgr_handle,
    sns_ddf_nv_params_s*     nv_params,
    sns_ddf_device_access_s  device_info[],
    uint32_t                 num_devices,
    sns_ddf_memhandler_s*    memhandler,
    sns_ddf_sensor_e*        sensors[],
    uint32_t*                num_sensors
)
{
    sns_ddf_status_e status;
    sns_dd_mag_state_t* ptr;
    static sns_ddf_sensor_e my_sensors[1] = {SNS_DDF_SENSOR_MAG};
/*
	static sns_ddf_sensor_e my_sensors[2] =
	{
		SNS_DDF_SENSOR_PROXIMITY,
    	SNS_DDF_SENSOR_AMBIENT
	};
	*/
	IST8307_MSG_1(HIGH,"SNS_DDF_SENSOR_MAG = %d",SNS_DDF_SENSOR_MAG);
	
    DD_MSG_0(HIGH, "MSensorLog [sns_dd_init]");
        
    
    status = sns_ddf_malloc((void**)&ptr, sizeof(sns_dd_mag_state_t));
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_init] error#1");
        return SNS_DDF_ENOMEM;
    }
        
    ptr->smgr_hndl = smgr_handle;
    //sns_ddf_get_port_id(&device_info->port_config,&ptr->my_port_id);
    
    status = sns_ddf_open_port(&ptr->port_handle, &device_info->port_config);
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_init] error#2");
        return status;
    }

    //mag_port_handle = ptr->port_handle;        
    *num_sensors = 2;
    *sensors = (sns_ddf_sensor_e *)my_sensors;
    *dd_handle_ptr = (sns_ddf_handle_t)ptr;
    sns_ddf_axes_map_init(
      &ptr->axes_map,
      ((nv_params != NULL) ? nv_params->data : NULL));
    status = sns_dd_mag_init(ptr);
	if(status != SNS_DDF_SUCCESS)
	{
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_init] error#3");
	}

#ifdef IST_CROSS_AXIS_CALI
    int crossaxis_enable = 0;
    char cross_mask[1];
    uint8_t wbuffer[2];

    cross_mask[0]= 0xFF;

    status = i2c_read(ptr->port_handle, IST8307_REG_XX_CROSS_L, 2, wbuffer);
	if(status != SNS_DDF_SUCCESS)
	{
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_init] error#44");
	}
    if((wbuffer[0] == cross_mask[0]) && (wbuffer[1] == cross_mask[0]))
        crossaxis_enable = 0;
    else
        crossaxis_enable = 1;

#ifdef SUPPORT_FLOAT_TYPE
    IST8307_Crossaxis_Matrix(ptr->port_handle,crossaxis_enable);
#else
    IST8307_Crossaxis_Matrix(ptr->port_handle,crossaxisinv_bitshift, crossaxis_enable);
#endif
#endif
    return SNS_DDF_SUCCESS;
}

static sns_ddf_status_e sns_dd_mag_config_power_mode(sns_dd_mag_state_t* dd_handle, sns_ddf_powerstate_e mode)
{
    sns_ddf_status_e status;
    uint8_t data, out;

    DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_config_power_mode]");
    IST8307_MSG_1(HIGH,"mode = %d",mode);
	IST8307_MSG_1(HIGH,"mode = %d",SNS_DDF_POWERSTATE_ACTIVE);
	IST8307_MSG_1(HIGH,"mode = %d",SNS_DDF_POWERSTATE_LOWPOWER);
    switch (mode)
    {
        case SNS_DDF_POWERSTATE_ACTIVE:

            data = 0x01;  //  Single measurement mode
            
            status = sns_ddf_write_port(dd_handle->port_handle, IST8307_REG_CNTRL1, &data, 1, &out);
			if(status != SNS_DDF_SUCCESS){
                IST8307_MSG_1(HIGH, "MSensorLog [sns_dd_mag_config_power_mode]:SNS_DDF_POWERSTATE_ACTIVE; port_handle=0x%x",dd_handle->port_handle);
				return status;
           	}
        break;

        case SNS_DDF_POWERSTATE_LOWPOWER:

            data = 0x00;  //  stand-by mode
            status = sns_ddf_write_port(dd_handle->port_handle, IST8307_REG_CNTRL1, &data, 1, &out);
			if(status != SNS_DDF_SUCCESS){
				IST8307_MSG_1(HIGH, "MSensorLog [sns_dd_mag_config_power_mode]:SNS_DDF_POWERSTATE_LOWPOWER port_handle=0x%x",dd_handle->port_handle);
				return status;
    		}
        break;

        default :
			DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_config_power_mode]:default");
            return SNS_DDF_EINVALID_PARAM;
    }

    return SNS_DDF_SUCCESS;
}

static sns_ddf_status_e sns_dd_mag_config_ODR(sns_dd_mag_state_t* dd_handle, uint32_t* odr)
{
    sns_ddf_status_e status;
    uint8_t data, out;

    DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_config_ODR]");
    
    data = sns_dd_mag_get_ODR(*odr); 
	IST8307_MSG_1(HIGH,"sns_dd_mag_config_ODR=%d",data);
    status = sns_ddf_write_port(dd_handle->port_handle, IST8307_REG_CNTRL1, &data, 1, &out);
    if(status != SNS_DDF_SUCCESS){
		IST8307_MSG_1(HIGH, "MSensorLog [sns_dd_mag_config_ODR]:port_handle=%x",dd_handle->port_handle);
        return status;
    }
    return SNS_DDF_SUCCESS;
}

static uint32_t sns_dd_mag_get_ODR(uint32_t odr)
{
    uint32_t i = 0;
uint32_t n = 0;
    
    DD_MSG_0(HIGH, "MSensorLog [sns_dd_mag_get_ODR]");

    n = sizeof(ODR_TABLE)/sizeof(ODR_ITEM);
    for (i=0; i<sizeof(ODR_TABLE)/sizeof(ODR_ITEM); i++)
    {
        if (ODR_TABLE[i].hz == odr)
            return ODR_TABLE[i].regval;
    }

    // ODR 20HZ or default
    return 5;
}

/*===========================================================================

FUNCTION:   sns_dd_set_attrib

===========================================================================*/
/*!
@brief Sets an attribute of the ALS/Prx sensor

@detail
Called by SMGR to set certain device attributes that are
programmable. Curently its the power mode, resolution and ODR.

@param[in] dd_handle   Handle to a driver instance.
@param[in] sensor Sensor for which this attribute is to be set.
@param[in] attrib      Attribute to be set.
@param[in] value      Value to set this attribute.

@return
The error code definition within the DDF 
SNS_DDF_SUCCESS on success; Otherwise SNS_DDF_EBUS or
SNS_DDF_EINVALID_PARAM

*/
/*=========================================================================*/
static sns_ddf_status_e sns_dd_set_attrib(
    sns_ddf_handle_t     dd_handle,
    sns_ddf_sensor_e     sensor,
    sns_ddf_attribute_e  attrib,
    void*                value
)
{
    sns_ddf_status_e ret_val = SNS_DDF_SUCCESS;
    sns_dd_mag_state_t *state = (sns_dd_mag_state_t *)dd_handle;
    DD_MSG_0(HIGH, "MSensorLog> [sns_dd_set_attrib]");
    
    switch(attrib)
    {
        case SNS_DDF_ATTRIB_POWER_STATE:
			

            ret_val = sns_dd_mag_config_power_mode((sns_dd_mag_state_t*)dd_handle,  *(sns_ddf_powerstate_e*)value);

        break;

        case SNS_DDF_ATTRIB_RANGE:

			DD_MSG_0(HIGH,"MSensorLog> [sns_dd_set_attrib] SNS_DDF_ATTRIB_RANGE");

        break;

        case SNS_DDF_ATTRIB_LOWPASS:

			DD_MSG_0(HIGH,"MSensorLog> [sns_dd_set_attrib] SNS_DDF_ATTRIB_LOWPASS");

        break;

        case SNS_DDF_ATTRIB_ODR:
			PM131_MSG_1(HIGH, "MSensorLog> config_ODR---*value = %d", *((uint32_t*)value));
			state->odr_value = *((uint32_t*)value);
			ret_val = sns_dd_mag_config_ODR((sns_dd_mag_state_t*)dd_handle,	(uint32_t*)value);


			DD_MSG_0(HIGH,"MSensorLog> [sns_dd_set_attrib] SNS_DDF_ATTRIB_ODR");

            return SNS_DDF_SUCCESS;
            

        break;

        case SNS_DDF_ATTRIB_RESOLUTION_ADC:
			DD_MSG_0(HIGH,"MSensorLog> [sns_dd_set_attrib] SNS_DDF_ATTRIB_RESOLUTION_ADC");

        break;

        default :
			DD_MSG_0(HIGH,"MSensorLog> [sns_dd_set_attrib] DEFAULT");
            return SNS_DDF_EINVALID_PARAM;
    }

    return ret_val;
}

/*===========================================================================

FUNCTION:   sns_dd_get_data

===========================================================================*/
/*!
@brief Called by the SMGR to get data

@detail
Requests a single sample of sensor data from each of the specified
sensors. Data is returned immediately after being read from the
sensor, in which case data[] is populated in the same order it was
requested

This driver is a pure asynchronous one, so no data will be written to buffer.
As a result, the return value will be always PENDING if the process does
not fail.  This driver will notify the Sensors Manager via asynchronous
notification when data is available.

@param[in]  dd_handle    Handle to a driver instance.
@param[in]  sensors      List of sensors for which data is requested.
@param[in]  num_sensors  Length of @a sensors.
@param[in]  memhandler   Memory handler used to dynamically allocate 
output parameters, if applicable.
@param[out] data         Sampled sensor data. The number of elements must 
match @a num_sensors.

@return SNS_DDF_SUCCESS if data was populated successfully. If any of the 
sensors queried are to be read asynchronously SNS_DDF_PENDING is
returned and data is via @a sns_ddf_smgr_data_notify() when
available. Otherwise a specific error code is returned.

*/
/*=========================================================================*/
static sns_ddf_status_e sns_dd_get_data(
    sns_ddf_handle_t        dd_handle,
    sns_ddf_sensor_e        sensors[],
    uint32_t                num_sensors,
    sns_ddf_memhandler_s*   memhandler,
    sns_ddf_sensor_data_s*  data[] /* ignored by this async driver */
)
{
    int i=0;
    sns_ddf_status_e status;
    uint8_t buffer[7], out;
    sns_ddf_sensor_data_s *data_ptr;
    sns_dd_mag_state_t *state = (sns_dd_mag_state_t *)dd_handle;

	init_lock = 0;


    status = sns_ddf_read_port(state->port_handle, IST8307_REG_STAT1, buffer, 7, &out);
    if(status != SNS_DDF_SUCCESS)
        return status;

#ifdef FORCE_MODE
    buffer[0] = 0x1; //force mode
    status = sns_ddf_write_port(state->port_handle, IST8307_REG_CNTRL1, buffer, 1, &out);
    if(status != SNS_DDF_SUCCESS)
        return status;
#endif

//	IST8307_MSG_1(HIGH,"size of short = %d",sizeof(short));
//	IST8307_MSG_1(HIGH,"size of q16_t = %d",sizeof(q16_t));
#if 0
	for(i = 1; i<=6;i++){
		IST8307_MSG_2(HIGH,"size of buffer[%d] = %d",i, buffer[i]);

	}

	for(i = 1; i <= 5; i = i + 2){
		IST8307_MSG_2(HIGH,"((short)((q16_t)buffer[2] << 8 | (q16_t)buffer[1]))[%d] = %d", i, ((short)((q16_t)buffer[i+1] << 8 | (q16_t)buffer[i])));

	}
#endif
#ifdef IST_CROSS_AXIS_CALI  // read from "IST8307_REG_STAT1" so take data from buffer[1]
	{
	    short xyz[3];
	    xyz[0] = ((short)((q16_t)buffer[2] << 8 | (q16_t)buffer[1]));
	    xyz[1] = ((short)((q16_t)buffer[4] << 8 | (q16_t)buffer[3]));
	    xyz[2] = ((short)((q16_t)buffer[6] << 8 | (q16_t)buffer[5]));
	    	    
	    IST8307_CrossaxisTransformation(xyz); //LSB?
	    state->data_cache[0] = FX_FLTTOFIX_Q16(0.01f*0.3f*xyz[0]);
	    state->data_cache[1] = FX_FLTTOFIX_Q16(0.01f*0.3f*xyz[1]);
	    state->data_cache[2] = FX_FLTTOFIX_Q16(0.01f*0.3f*xyz[2]);
    }
#else
    state->data_cache[0] = FX_FLTTOFIX_Q16(0.01f*0.3f*((short)((q16_t)buffer[2] << 8 | (q16_t)buffer[1])));
    state->data_cache[1] = FX_FLTTOFIX_Q16(0.01f*0.3f*((short)((q16_t)buffer[4] << 8 | (q16_t)buffer[3])));
    state->data_cache[2] = FX_FLTTOFIX_Q16(0.01f*0.3f*((short)((q16_t)buffer[6] << 8 | (q16_t)buffer[5])));
#endif
#if 0
	for(i = 0; i<3;i++){
		IST8307_MSG_2(HIGH,"size of state->data_cache[%d] = %d",i, state->data_cache[i]);
	}
#endif	
    data_ptr = sns_ddf_memhandler_malloc(memhandler, num_sensors * sizeof(sns_ddf_sensor_data_s));
    if(data_ptr == NULL)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_get_data]:SNS_DDF_ENOMEM error#1");
        return SNS_DDF_ENOMEM;
    }   
    *data = data_ptr;
    
    for(i=0; i <num_sensors; i++)
    {
        data_ptr[i].sensor = sensors[i];
        data_ptr[i].status = SNS_DDF_SUCCESS;
        data_ptr[i].timestamp = sns_ddf_get_timestamp();

        if(sensors[i] == SNS_DDF_SENSOR_MAG)
        {
            data_ptr[i].samples = sns_ddf_memhandler_malloc(memhandler, 3*sizeof(sns_ddf_sensor_sample_s));
            if(data_ptr[i].samples == NULL)
            {
                DD_MSG_0(HIGH, "MSensorLog [sns_dd_get_data]:SNS_DDF_ENOMEM error#2");
                return SNS_DDF_ENOMEM;
            }
            data_ptr[i].samples[0].sample = state->data_cache[0];
            data_ptr[i].samples[1].sample = state->data_cache[1];
            data_ptr[i].samples[2].sample = state->data_cache[2];

            data_ptr[i].samples[0].status = SNS_DDF_SUCCESS;
            data_ptr[i].samples[1].status = SNS_DDF_SUCCESS;
            data_ptr[i].samples[2].status = SNS_DDF_SUCCESS;
            
            data_ptr[i].num_samples = 3;
        }
    }
    return SNS_DDF_SUCCESS;
}

/*===========================================================================

FUNCTION:   sns_dd_get_attrib

===========================================================================*/
/*!
@brief Called by the SMGR to retrieves the value of an attribute of
the sensor.

@detail
Returns the requested attribute

@param[in]  handle      Handle to a driver instance.
@param[in]  sensor      Sensor whose attribute is to be retrieved.
@param[in]  attrib      Attribute to be retrieved. 
@param[in]  memhandler  Memory handler used to dynamically allocate 
output parameters, if applicable.
@param[out] value       Pointer that this function will allocate or set 
to the attribute's value.
@param[out] num_elems   Number of elements in @a value.

@return
Success if the attribute was retrieved and the buffer was 
populated. Otherwise a specific error code is returned.
*/
/*=========================================================================*/
//tyhuang
static sns_ddf_status_e sns_dd_get_attrib(
    sns_ddf_handle_t     dd_handle,
    sns_ddf_sensor_e     sensor,
    sns_ddf_attribute_e  attrib,
    sns_ddf_memhandler_s* memhandler,
    void**                value,
    uint32_t*             num_elems
)
{
    sns_ddf_power_info_s* power_attrib;
    sns_ddf_range_s *device_ranges;
    sns_ddf_resolution_adc_s *device_res;
    sns_ddf_delays_s *device_delay;
    sns_ddf_device_info_s *device_info;
    sns_ddf_driver_info_s *driver_info_ptr;
    sns_ddf_registry_group_s  *reg_group_ptr;
    sns_dd_nv_db_type *reg_group_data_ptr;
    sns_dd_mag_state_t *state = (sns_dd_mag_state_t *)dd_handle;
    uint32_t* odr_ptr;


	IST8307_MSG_2(MED, "get_attrib() - sensor=%d attr=%d", sensor, attrib);

	
    switch(attrib)
    {
        case SNS_DDF_ATTRIB_POWER_INFO:
        {
			IST8307_MSG_0(HIGH,"SNS_DDF_ATTRIB_POWER_INFO");
            *value = sns_ddf_memhandler_malloc(memhandler,  sizeof(sns_ddf_power_info_s));
            if(*value == NULL)
                return SNS_DDF_ENOMEM;

            power_attrib = *value;

            power_attrib->active_current = 600;// 0.6mA
            power_attrib->lowpower_current = 10;// 10uA
            *num_elems = 1;
        }
        break;

        case SNS_DDF_ATTRIB_DRIVER_INFO:
            IST8307_MSG_0(HIGH,"SNS_DDF_ATTRIB_DRIVER_INFO");
            driver_info_ptr = sns_ddf_memhandler_malloc(memhandler, sizeof(sns_ddf_driver_info_s));
            if(driver_info_ptr == NULL)
                return SNS_DDF_ENOMEM;

            driver_info_ptr->name    = "IST MAG-Series";
            driver_info_ptr->version = 1;
            *(sns_ddf_driver_info_s**)value = driver_info_ptr;
            *num_elems = 1;
            //generic_attrib = true;

        break;

        case SNS_DDF_ATTRIB_REGISTRY_GROUP:

			IST8307_MSG_0(HIGH,"SNS_DDF_ATTRIB_REGISTRY_GROUP");
            reg_group_ptr = sns_ddf_memhandler_malloc(memhandler, sizeof(sns_ddf_registry_group_s));
            if(reg_group_ptr == NULL)
                return SNS_DDF_ENOMEM;

            reg_group_ptr->group_data = sns_ddf_memhandler_malloc(memhandler, state->sns_dd_common_db.nv_size);
            if(reg_group_ptr->group_data == NULL)
                return SNS_DDF_ENOMEM;

            reg_group_data_ptr = (sns_dd_nv_db_type*)reg_group_ptr->group_data;
            
            reg_group_data_ptr->nv_size = state->sns_dd_common_db.nv_size;
            reg_group_data_ptr->visible_ratio = state->sns_dd_common_db.visible_ratio;
            reg_group_data_ptr->ir_ratio = state->sns_dd_common_db.ir_ratio;
            reg_group_data_ptr->version_num = state->sns_dd_common_db.version_num;
            reg_group_data_ptr->thresh_near = state->sns_dd_common_db.thresh_near;
            reg_group_data_ptr->thresh_far = state->sns_dd_common_db.thresh_far;
            reg_group_data_ptr->calibratePhone = state->sns_dd_common_db.calibratePhone;
            reg_group_data_ptr->device = state->sns_dd_common_db.device;

            reg_group_ptr->size = state->sns_dd_common_db.nv_size;
            *(sns_ddf_registry_group_s**)value = reg_group_ptr;
            *num_elems = 1;

        break;

        case SNS_DDF_ATTRIB_RANGE:
        {
			IST8307_MSG_0(HIGH,"SNS_DDF_ATTRIB_RANGE");
            *value = sns_ddf_memhandler_malloc(memhandler, 10*sizeof(sns_ddf_range_s));
            if(*value == NULL)
                return SNS_DDF_ENOMEM;

            device_ranges = *value;


			IST8307_MSG_2(HIGH,"get_attr_SNS_DDF_ATTRIB_RANGE sensor = %d SENSOR_MAG = %d",sensor,SNS_DDF_SENSOR_MAG);
            if(sensor == SNS_DDF_SENSOR_MAG)
            {
                device_ranges[0].min = FX_FLTTOFIX_Q16(-16);
                device_ranges[0].max = FX_FLTTOFIX_Q16(16);
                device_ranges[1].min = FX_FLTTOFIX_Q16(-16);
                device_ranges[1].max = FX_FLTTOFIX_Q16(16);
                device_ranges[2].min = FX_FLTTOFIX_Q16(-16);
                device_ranges[2].max = FX_FLTTOFIX_Q16(16);
                *num_elems = 3;
            }
        }
        break;

        case SNS_DDF_ATTRIB_LOWPASS:
			IST8307_MSG_0(HIGH,"SNS_DDF_ATTRIB_LOWPASS");
        #if 0
        {
            *num_elems = 3;
            sns_ddf_lowpass_freq_t *freq_set;
            *value = sns_ddf_memhandler_malloc(memhandler, (*num_elems)*sizeof(sns_ddf_lowpass_freq_t));
            if(*value == NULL)
                return SNS_DDF_ENOMEM;

            freq_set = *value;
        }
        #endif
        break;
    
        case SNS_DDF_ATTRIB_RESOLUTION_ADC: //case 4
        {
			IST8307_MSG_0(HIGH,"SNS_DDF_ATTRIB_RESOLUTION_ADC");
            *value = sns_ddf_memhandler_malloc(memhandler, sizeof(sns_ddf_resolution_adc_s));
            if(*value == NULL)
                return SNS_DDF_ENOMEM;
            
            device_res = *value;
    
            *num_elems = 1;
            device_res->bit_len = 14;   //13.36
            device_res->max_freq = 200;
        }
        break;
    
        case SNS_DDF_ATTRIB_DELAYS:
        {
			IST8307_MSG_0(HIGH,"SNS_DDF_ATTRIB_DELAYS");
            *value = sns_ddf_memhandler_malloc(memhandler, sizeof(sns_ddf_delays_s));
            if(*value == NULL)
                return SNS_DDF_ENOMEM;

            device_delay = *value;
            
            *num_elems = 1;
            device_delay->time_to_active = 30;
            device_delay->time_to_data = 30;
        }
        break;

        case SNS_DDF_ATTRIB_DEVICE_INFO:
        {
			IST8307_MSG_0(HIGH,"SNS_DDF_ATTRIB_DEVICE_INFO");
            *value = sns_ddf_memhandler_malloc(memhandler, sizeof(sns_ddf_device_info_s));
            if(*value == NULL)
                return SNS_DDF_ENOMEM;
            
            device_info = *value;
            
            *num_elems = 1;
            device_info->model = "IST8307";
            device_info->vendor = "IST";
            device_info->name = "Magnetometer";
            device_info->version = 1;
        }
        break;
    
        case SNS_DDF_ATTRIB_BIAS:
        {
			IST8307_MSG_0(HIGH,"SNS_DDF_ATTRIB_BIAS");
            *value = sns_ddf_memhandler_malloc(memhandler, sizeof(sns_dd_mag_state_t));
            if(*value == NULL)
                return SNS_DDF_ENOMEM;
    
            *value = state->bias;
            *num_elems = 3;
        }
        break;
   
        case SNS_DDF_ATTRIB_ODR:  //13
        {

			IST8307_MSG_0(HIGH,"SNS_DDF_ATTRIB_ODR");
            *value = sns_ddf_memhandler_malloc(memhandler, sizeof(uint32_t));
            if (*value == NULL){
				IST8307_MSG_0(HIGH,"value=null");
                return SNS_DDF_ENOMEM;
            }
            *num_elems = 1;
            odr_ptr = *value;
            *odr_ptr = state->odr_value;
        }
        break;
        case SNS_DDF_ATTRIB_SUPPORTED_ODR_LIST:
        {
            sns_ddf_odr_t *odr_list;
	    uint32_t i;
            odr_list = sns_ddf_memhandler_malloc(memhandler,	sizeof(mag_odr_list));
            if (odr_list == NULL)
            {
                IST8307_MSG_0(HIGH,"ODR LIST memory error");
                return SNS_DDF_ENOMEM;
            }
		*num_elems = sizeof(mag_odr_list)/sizeof(sns_ddf_odr_t);
		for (i=0; i<*num_elems; i++)
		{
			odr_list[i] = mag_odr_list[i];
		}
		*value = odr_list;	
        }
        break; 
        default :
			IST8307_MSG_0(HIGH,"DEFAULT");

			IST8307_MSG_2(HIGH,"SNS_DDF_EINVALID_ATTR & SNS_DDF_EINVALID_param %d %d ",SNS_DDF_EINVALID_ATTR, SNS_DDF_EINVALID_PARAM);
		
		return SNS_DDF_EINVALID_ATTR;
    }

    return SNS_DDF_SUCCESS;
}


/*===========================================================================

FUNCTION:   sns_dd_run_test

===========================================================================*/
/*!
@ Called by the SMGR to run calibration test for ALS or PRX.

@detail
Returns the cal_factor in error, to be stored in NV memory

@param[in]  handle      Handle to a driver instance.
@param[in]  sensor_type Sensor whose attribute is to be retrieved.
@param[in] test         Test ID used to decide what to test.
@param[out] err         prx_factor or als_factor.

@return
Success if no error. Otherwise a specific error code is returned.
*/
/*=========================================================================*/

static sns_ddf_status_e sns_dd_run_test(
    sns_ddf_handle_t    handle,
    sns_ddf_sensor_e    sensor_type,
    sns_ddf_test_e      test,
    uint32_t*           err
)
{
    
#if 0
    sns_ddf_status_e status;
    sns_dd_mag_state_t* ptr;
    
    //run reset
    status = sns_dd_reset(handle);
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_run_test] reset error");
        return status;
    }
    ptr = (sns_dd_mag_state_t*) &handle;
    status = sns_dd_mag_init(ptr);
    if(status != SNS_DDF_SUCCESS)
    {
        DD_MSG_0(HIGH, "MSensorLog [sns_dd_run_test] sns_dd_mag_init error");
        return status;
    }
#endif
    DD_MSG_0(HIGH, "MSensorLog [sns_dd_run_test] done MSensorLog");
    return SNS_DDF_SUCCESS;
}

/*===========================================================================

FUNCTION:   sns_dd_probe

===========================================================================*/
/**
* @brief Probes for the device with a given configuration.
*
* This commands the driver to look for the device with the specified
* configuration (ie, I2C address/bus defined in the sns_ddf_device_access_s
* struct.
*
* @param[in]  dev_info    Access info for physicol devices controlled by 
*                         this driver. Used to determine if the device is
*                         physically present.
* @param[in]  memhandler  Memory handler used to dynamically allocate 
*                         output parameters, if applicable.
* @param[out] num_sensors Number of sensors supported. 0 if none.
* @param[out] sensor_type Array of sensor types supported, with num_sensor
*                         elements. Allocated by this function.
*
* @return SNS_DDF_SUCCESS if the part was probed function completed, even
*         if no device was found (in which case num_sensors will be set to
*         0).
*/
static sns_ddf_status_e sns_dd_probe(
    sns_ddf_device_access_s* device_info,
    sns_ddf_memhandler_s*    memhandler,
    uint32_t*                num_sensors,
    sns_ddf_sensor_e**       sensors
)
{

    *num_sensors = 1;
    *sensors = sns_ddf_memhandler_malloc(memhandler, sizeof(sns_ddf_sensor_e)*(*num_sensors));

	DD_MSG_0(HIGH, "MSensorLog [sns_dd_probe] done");
#if 0
    if(*sensors != NULL)
#endif
        (*sensors)[0] = SNS_DDF_SENSOR_MAG;
    
    return SNS_DDF_SUCCESS;
}

static sns_ddf_status_e sns_dd_enable_sched_data(
    sns_ddf_handle_t  handle,
    sns_ddf_sensor_e  sensor,
    bool              enable
)
{
    DD_MSG_0(HIGH, "MSensorLog [sns_dd_enable_sched_data] done");
    return SNS_DDF_SUCCESS;
}
