/*===========================================================================

EDIT HISTORY FOR FILE

This section contains comments describing changes made to the module.
Notice that changes are listed in reverse chronological order.

when         who     what, where, why
--------     ---     ------------------------------------------------------ 
2015/12/24  tyhuang     v1.0.0
==========================================================================*/

#ifndef _DD_VENDOR_1_H
#define _DD_VENDOR_1_H

#include "fixed_point.h"
#include "sns_ddf_util.h"
#include "qurt_elite_diag.h"
#include "sns_log_api_public.h"
#include "sns_log_types_public.h"

#include "stdint.h"

#define IST8307_SLA                 0x0C    //IST8307 Slave Address
//#define SUPPORT_FLOAT_TYPE  1
#define IST_CROSS_AXIS_CALI

#define     FORCE_MODE      1
#define     SUPPORT_8307    1

#ifdef IST_CROSS_AXIS_CALI
/*---IST8307 cross-axis matrix Address-----------------danny-----*/

#define IST8307_AXIS_X            0
#define IST8307_AXIS_Y            1
#define IST8307_AXIS_Z            2
#define IST8307_AXES_NUM          3
#endif
typedef struct
{
    uint8_t  nv_size;         /* size of NV item */
    uint8_t  visible_ratio;   /* visible light transmission ratio of the glass/pipe in % */
    uint8_t  ir_ratio;        /* IR transmission ratio of light glass/pipe in % */
    uint16_t version_num;     /* Version of NV Database */
    uint16_t thresh_near;     /* near detection threshold in ADC count adjusted by DC offset */
    uint16_t thresh_far;      /* far detection threshold in ADC count adjusted by DC offset */
    uint8_t  calibratePhone;  /* if true, calibrate phone (should only have to done during manufacture) */
    uint32_t device;          /* current sensor */
} sns_dd_nv_db_type;

#define IST8307dbg 1

#ifdef IST8307dbg
#define DBG_MEDIUM_PRIO DBG_MED_PRIO
#define IST8307_MSG_0(level,msg)          MSG(MSG_SSID_QDSP6,DBG_##level##_PRIO, "IST8307 - " msg)
#define IST8307_MSG_1(level,msg,p1)       MSG_1(MSG_SSID_QDSP6,DBG_##level##_PRIO, "IST8307 - " msg,p1)
#define IST8307_MSG_2(level,msg,p1,p2)    MSG_2(MSG_SSID_QDSP6,DBG_##level##_PRIO, "IST8307 - " msg,p1,p2)
#define IST8307_MSG_3(level,msg,p1,p2,p3) MSG_3(MSG_SSID_QDSP6,DBG_##level##_PRIO, "IST8307 - " msg,p1,p2,p3)
#endif
/*
#elif ! defined(ADSP_STANDALONE)
#define MED MEDIUM
#include "sns_debug_str.h"
#define IST8307_MSG_0(level,msg)          SNS_PRINTF_STRING_ID_##level##_0(SNS_DBG_MOD_DSPS_SMGR,DBG_DD_ALSPRX_STRING0)
#define IST8307_MSG_1(level,msg,p1)       SNS_PRINTF_STRING_ID_##level##_1(SNS_DBG_MOD_DSPS_SMGR,DBG_DD_ALSPRX_STRING1,p1)
#define IST8307_MSG_2(level,msg,p1,p2)    SNS_PRINTF_STRING_ID_##level##_2(SNS_DBG_MOD_DSPS_SMGR,DBG_DD_ALSPRX_STRING2,p1,p2)
#define IST8307_MSG_3(level,msg,p1,p2,p3) SNS_PRINTF_STRING_ID_##level##_3(SNS_DBG_MOD_DSPS_SMGR,DBG_DD_ALSPRX_STRING3,p1,p2,p3)
#else
#define IST8307_MSG_0(level,msg)          printf(msg)
#define IST8307_MSG_1(level,msg,p1)       printf(msg,p1)
#define IST8307_MSG_2(level,msg,p1,p2)    printf(msg,p1,p2)
#define IST8307_MSG_3(level,msg,p1,p2,p3) printf(msg,p1,p2,p3)
#endif
#else
#define IST8307_MSG_0(level,msg)
#define IST8307_MSG_1(level,msg,p1)
#define IST8307_MSG_2(level,msg,p1,p2)
#define IST8307_MSG_3(level,msg,p1,p2,p3)
#endif
*/

#define IST8307 0.3f



#define IST8307_CHIP_ID				0xff
#define IST8307_REG_WIA				0x00  //  who i am
#define IST8307_REG_MINFO			0x01  //  more info
#define IST8307_REG_STAT1			0x02  //  status register 1
#define IST8307_REG_DATAX_L			0x03  //  output value x low byte
#define IST8307_REG_DATAX_H		    0x04  //  output value x high byte
#define IST8307_REG_DATAY_L			0x05  //  output value y low byte
#define IST8307_REG_DATAY_H		    0x06  //  output value y high byte
#define IST8307_REG_DATAZ_L			0x07  //  output value z low byte
#define IST8307_REG_DATAZ_H		    0x08  //  output value z high byte
#define IST8307_REG_STAT2			0x09  //  status register 2
#define IST8307_REG_CNTRL1			0x0A  //  Control setting register 1
#define IST8307_REG_CNTRL2			0x0B  //  Control setting register 2
#define IST8307_REG_STCR			0x0C  //  self test control
#define IST8307_REG_CNTRL3			0x0D  //  Control setting register 3
#define IST8307_REG_TEMP_L			0x1C  //  low byte of temperature data
#define IST8307_REG_TEMP_H		    0x1D  //  high byte of temperature data
#define IST8307_REG_HW_AVE          0x41
#define IST8307_REG_SSR             0x42  //  sensor selection register
#define IST8307_REG_CTR             0x40  //  chip test register
#define IST8307_REG_BTR             0x57  //  bangap tuning register

#define IST8307_REG_XX_CROSS_L      0x9C   //cross axis xx low byte
#define IST8307_REG_XX_CROSS_H      0x9D   //cross axis xx high byte
#define IST8307_REG_XY_CROSS_L      0x9E   //cross axis xy low byte
#define IST8307_REG_XY_CROSS_H      0x9F   //cross axis xy high byte
#define IST8307_REG_XZ_CROSS_L      0xA0   //cross axis xz low byte
#define IST8307_REG_XZ_CROSS_H      0xA1   //cross axis xz high byte

#define IST8307_REG_YX_CROSS_L      0xA2   //cross axis yx low byte
#define IST8307_REG_YX_CROSS_H      0xA3   //cross axis yx high byte
#define IST8307_REG_YY_CROSS_L      0xA4   //cross axis yy low byte
#define IST8307_REG_YY_CROSS_H      0xA5   //cross axis yy high byte
#define IST8307_REG_YZ_CROSS_L      0xA6   //cross axis yz low byte
#define IST8307_REG_YZ_CROSS_H      0xA7   //cross axis yz high byte

#define IST8307_REG_ZX_CROSS_L      0xA8   //cross axis zx low byte
#define IST8307_REG_ZX_CROSS_H      0xA9   //cross axis zx high byte
#define IST8307_REG_ZY_CROSS_L      0xAA   //cross axis zy low byte
#define IST8307_REG_ZY_CROSS_H      0xAB   //cross axis zy high byte
#define IST8307_REG_ZZ_CROSS_L      0xAC   //cross axis zz low byte
#define IST8307_REG_ZZ_CROSS_H      0xAD   //cross axis zz high byte


// Enable the following macro to see debug out 
//#define DD_VENDOR_1_DEBUG

#endif /* End include guard  _DD_VENDOR_1_H */
